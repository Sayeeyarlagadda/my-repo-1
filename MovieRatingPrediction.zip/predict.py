
import pickle
import pandas as pd

with open("movie_model.pkl", "rb") as f:
    model = pickle.load(f)

movie = pd.DataFrame([{
    "Genre": "Action",
    "Duration_Min": 140,
    "Budget_Crore_INR": 100,
    "Popularity_Index": 85
}])

prediction = model.predict(movie)

print("Predicted Movie Rating:", round(prediction[0], 2))
