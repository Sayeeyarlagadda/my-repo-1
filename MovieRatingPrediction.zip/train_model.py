
import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error

def create_model():

    numeric = [
        "Duration_Min",
        "Budget_Crore_INR",
        "Popularity_Index"
    ]

    preprocessor = ColumnTransformer([
        ("genre", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore"))
        ]), ["Genre"]),

        ("numeric", SimpleImputer(strategy="median"), numeric)
    ])

    return Pipeline([
        ("preprocessing", preprocessor),
        ("regression", LinearRegression())
    ])

def train():

    df = pd.read_csv("movie.csv")

    X = df[[
        "Genre",
        "Duration_Min",
        "Budget_Crore_INR",
        "Popularity_Index"
    ]]

    y = df["Rating_10"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = create_model()
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)

    print("R2 Score:", r2_score(y_test, predictions))
    print("MAE:", mean_absolute_error(y_test, predictions))

    # Retrain using complete dataset
    model.fit(X, y)

    with open("movie_model.pkl", "wb") as f:
        pickle.dump(model, f)

    print("Model trained and saved successfully!")

if __name__ == "__main__":
    train()
