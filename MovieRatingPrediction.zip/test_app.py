
import pandas as pd
from train_model import create_model

def test_movie_prediction():

    X = pd.DataFrame({
        "Genre": ["Action", "Comedy", "Drama", "Action"],
        "Duration_Min": [120, 100, 140, 110],
        "Budget_Crore_INR": [50, 20, 30, 40],
        "Popularity_Index": [75, 60, 80, 70]
    })

    y = [8.0, 6.0, 7.0, 7.5]

    model = create_model()
    model.fit(X, y)

    new_movie = pd.DataFrame([{
        "Genre": "Action",
        "Duration_Min": 120,
        "Budget_Crore_INR": 50,
        "Popularity_Index": 75
    }])

    result = model.predict(new_movie)

    assert len(result) == 1
    assert 0 <= result[0] <= 10
